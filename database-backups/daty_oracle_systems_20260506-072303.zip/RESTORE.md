﻿# استعادة نسخة قاعدة البيانات

هذه النسخة تحتوي تصدير Oracle legacy للسكيمات:

`DATAALA, DATAALB, DATAALC, DATAALD, DATAALE, DATAALF, DATAALG, DATAALR`

## الملفات

- `daty_oracle_systems.dmp`: ملف التصدير.
- `daty_oracle_systems.exp.log`: سجل التصدير.
- `manifest.json`: معلومات النسخة.

## الاستعادة المختصرة

على الجهاز الآخر تحتاج Oracle Database متوافق و Oracle import tool `imp.exe`.
أنشئ المستخدمين/السكيمات أو استورد بصلاحية DBA، ثم استخدم ملف dump للاستيراد.
مثال عام بدون كلمات مرور:

```bat
imp USERID=system/your_password@your_db FILE=daty_oracle_systems.dmp FULL=Y LOG=daty_oracle_systems.imp.log
```

إذا أردت، اطلب مني لاحقًا تجهيز سكربت استعادة مفصل حسب اسم قاعدة البيانات في الجهاز الجديد.
